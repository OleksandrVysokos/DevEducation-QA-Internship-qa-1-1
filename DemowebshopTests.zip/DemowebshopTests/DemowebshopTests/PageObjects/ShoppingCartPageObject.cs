﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemowebshopTests.PageObjects
{
    class ShoppingCartPageObject
    {
        private IWebDriver _webdriver;
        private readonly By _selectYourCountry = By.XPath("//option[@value='1']");
        private readonly By _agreeTermsOfService = By.CssSelector("#termsofservice");
        private readonly By _checkoutButton = By.CssSelector("#checkout");
        private readonly By _continueBillingAddress = By.XPath("//input[@title='Continue']");
        private readonly By _continueShippingAddress = By.XPath("//input[@onclick='Shipping.save()']");
        private readonly By _continueShippingMethod = By.XPath("//input[@onclick='ShippingMethod.save()']");
        private readonly By _selectPaymentMethodByCreditCard = By.XPath("//input[@id='paymentmethod_2']");
        private readonly By _continuePaymentMethod = By.XPath("//input[@onclick='PaymentMethod.save()']");
        private readonly By _enterCardholderName = By.XPath("//input[@id='CardholderName']");
        private const string _validCardholderName = "User Userok";
        private readonly By _enterCardNumber = By.XPath("//input[@id='CardNumber']");
        private const string _validCardNumber = "5168 7573 3981 6904";
        private readonly By _enterCardCode = By.XPath("//input[@id='CardCode']");
        private const string _validCardCode = "666";
        private readonly By _PaymentInfoSave = By.XPath("//input[@onclick='PaymentInfo.save()']");
        private readonly By _confirmOrder = By.XPath("//input[@onclick='ConfirmOrder.save()']");
        public ShoppingCartPageObject(IWebDriver webdriver)
        {
            _webdriver = webdriver;
        }

        public ShoppingCartPageObject SelectCountryAndAgreeButton()
        {
            WaitUntil.WaitElement(_webdriver, _selectYourCountry);
            _webdriver.FindElement(_selectYourCountry).Click();
            WaitUntil.WaitElement(_webdriver, _agreeTermsOfService);
            _webdriver.FindElement(_agreeTermsOfService).Click();
            WaitUntil.WaitElement(_webdriver, _checkoutButton);
            _webdriver.FindElement(_checkoutButton).Click();
            return new ShoppingCartPageObject(_webdriver);
        }
        public ShoppingCartPageObject EndingOfCheckout()
        {
            WaitUntil.WaitElement(_webdriver, _continueBillingAddress);
            _webdriver.FindElement(_continueBillingAddress).Click();
            WaitUntil.WaitElement(_webdriver, _continueShippingAddress);
            _webdriver.FindElement(_continueShippingAddress).Click();
            WaitUntil.WaitElement(_webdriver, _continueShippingMethod);
            _webdriver.FindElement(_continueShippingMethod).Click();
            WaitUntil.WaitElement(_webdriver, _selectPaymentMethodByCreditCard);
            _webdriver.FindElement(_selectPaymentMethodByCreditCard).Click();
            WaitUntil.WaitElement(_webdriver, _continuePaymentMethod);
            _webdriver.FindElement(_continuePaymentMethod).Click();
            WaitUntil.WaitElement(_webdriver, _enterCardholderName);
            _webdriver.FindElement(_enterCardholderName).SendKeys(_validCardholderName);
            WaitUntil.WaitElement(_webdriver, _enterCardNumber);
            _webdriver.FindElement(_enterCardNumber).SendKeys(_validCardNumber);
            WaitUntil.WaitElement(_webdriver, _enterCardCode);
            _webdriver.FindElement(_enterCardCode).SendKeys(_validCardCode);
            WaitUntil.WaitElement(_webdriver, _PaymentInfoSave);
            _webdriver.FindElement(_PaymentInfoSave).Click();
            WaitUntil.WaitElement(_webdriver, _confirmOrder);
            _webdriver.FindElement(_confirmOrder).Click();

            return new ShoppingCartPageObject(_webdriver);       
        }

    }
}
