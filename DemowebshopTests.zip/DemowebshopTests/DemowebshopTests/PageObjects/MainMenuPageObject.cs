﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace DemowebshopTests.PageObjects
{
    class MainMenuPageObject
    {
        private IWebDriver _webDriver;
        private readonly By _registerButton = By.XPath("//a[@href='/register']");
        private readonly By _logInInputButton = By.CssSelector(".ico-login");
        private readonly By _goToItemPage = By.XPath("//a[@href='/141-inch-laptop']");
        private readonly By _addToCartFromItemPage = By.CssSelector("#add-to-cart-button-31");
        private readonly By _contactUsFormButton = By.XPath("//a[@href='/contactus']");
        private readonly By _giftCardCategoryOpen = By.XPath("//a[@href='/gift-cards']");
        private readonly By _booksCategoryOpen = By.XPath("//a[@href='/books']");
        private readonly By _goToShoppingCart = By.CssSelector(".cart-label");
        public MainMenuPageObject(IWebDriver webDriver)
        {
            _webDriver = webDriver;
        }
        public RegisterFormPageObject Registration()
        {
            _webDriver.FindElement(_registerButton).Click();
            return new RegisterFormPageObject(_webDriver);

        }
        public AuthorizationFormPageObject Authorization()
        {
            _webDriver.FindElement(_logInInputButton).Click();
            return new AuthorizationFormPageObject(_webDriver);
        }
        public ItemPagePageObject OpenItemPage()
        {
    
            _webDriver.FindElement(_goToItemPage).Click();
            return new ItemPagePageObject(_webDriver);
        }
        public ItemPagePageObject AddToCartFromItemPage()
        {
         
            _webDriver.FindElement(_addToCartFromItemPage).Click();
            return new ItemPagePageObject(_webDriver);
        }
        public MainMenuPageObject OpenContactUsForm()
        {
            WaitUntil.WaitElement(_webDriver, _contactUsFormButton);
            _webDriver.FindElement(_contactUsFormButton).Click();
            return new MainMenuPageObject(_webDriver);
        }
        public MainMenuPageObject OpenGiftCardCategoryPage()
        {
            WaitUntil.WaitElement(_webDriver, _giftCardCategoryOpen);
            _webDriver.FindElement(_giftCardCategoryOpen).Click();
            return new MainMenuPageObject(_webDriver);
        }
        public MainMenuPageObject OpenBooksCategoryPage()
        {
            WaitUntil.WaitElement(_webDriver, _booksCategoryOpen);
            _webDriver.FindElement(_booksCategoryOpen).Click();
            return new MainMenuPageObject(_webDriver);
        
        }
        public MainMenuPageObject OpenShoppingCartPage()
        {
            WaitUntil.WaitElement(_webDriver, _goToShoppingCart);
            _webDriver.FindElement(_goToShoppingCart).Click();
            return new MainMenuPageObject(_webDriver);
        }

    }
}
