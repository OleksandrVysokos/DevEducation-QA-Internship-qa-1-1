﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemowebshopTests.PageObjects
{
    class LeftSidebarMenuPageObject
    {
        private IWebDriver _webdriver;
        private readonly By _computersMenuButton = By.XPath("//a[@href='/computers']");
        private readonly By _computersDesktopsButton = By.XPath("//img[@src='http://demowebshop.tricentis.com/content/images/thumbs/0000003_desktops_125.jpg']");
        private readonly By _computersNotebooksButton = By.XPath("//img[@src='http://demowebshop.tricentis.com/content/images/thumbs/0000232_notebooks_125.png']");
        private readonly By _jawerlyMenuButton = By.XPath("//a[@href='/jewelry']");


        public LeftSidebarMenuPageObject(IWebDriver webDriver)
        {
            _webdriver = webDriver;
        }

        public LeftSidebarMenuPageObject OpenComputersMenu()
        {
            WaitUntil.WaitElement(_webdriver, _computersMenuButton);
            _webdriver.FindElement(_computersMenuButton).Click();
            return new LeftSidebarMenuPageObject(_webdriver);
        }
        public LeftSidebarMenuPageObject OpenPageOfDesktops()
        {
            WaitUntil.WaitElement(_webdriver, _computersDesktopsButton);
            _webdriver.FindElement(_computersDesktopsButton).Click();
            return new LeftSidebarMenuPageObject(_webdriver);
        }
        public LeftSidebarMenuPageObject OpenPageOfNotebooks()
        {
            WaitUntil.WaitElement(_webdriver, _computersNotebooksButton);
            _webdriver.FindElement(_computersNotebooksButton).Click();
            return new LeftSidebarMenuPageObject(_webdriver);
        }
        public LeftSidebarMenuPageObject OpenPageOfJawerly()
        {
            WaitUntil.WaitElement(_webdriver, _jawerlyMenuButton);
            _webdriver.FindElement(_jawerlyMenuButton).Click();
            return new LeftSidebarMenuPageObject(_webdriver);
        }

    }
}
