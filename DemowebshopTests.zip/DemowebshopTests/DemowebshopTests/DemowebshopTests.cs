using DemowebshopTests.PageObjects;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Linq;
using System.Threading;
using TechTalk.SpecFlow;

namespace DemowebshopTests
{
    public class Tests
    {
        #region
        private IWebDriver _webDriver;
        private readonly By _afterSuccessfullRegister = By.XPath("//div[@class='result']");
        private readonly By _UnsuccessfullRegistrationEmailAlreadyRegistred = By.XPath("//div[@class='validation-summary-errors']");
        private readonly By _afterSuccessfullLogin = By.XPath("//a[@class='account']");
        private const string _expectedAfterUnsuccessfullRegisterWhenEmailAlreadyRegistred = "The specified email already exists";
        private const string _expectedLogin = "ukraine993377@gmail.com";
        private const string _expectedRegistrationResult = "Your registration completed";
        private readonly By _actualPriceInCompareList = By.XPath("//tr[@class='product-price']");
        private const string _expectedPriceInCompareList = "Price 800.00";
        private readonly By _actualResultAfterSendingMessage = By.XPath("//div[@class='result']");
        private const string _expectedResultAfterSendingMessage = "Your enquiry has been successfully sent to the store owner.";
        private readonly By _actualResultOfCheckout = By.XPath("//div[@class='title']");
        private const string _expectedResultAfterCheckout = "Your order has been successfully processed!";
        #endregion

        [SetUp]
        public void Setup()
        {
            _webDriver = new ChromeDriver();
            _webDriver.Navigate().GoToUrl(" http://demowebshop.tricentis.com/");
            _webDriver.Manage().Window.Maximize();
        }

        [Test]
        public void RegisterUsingValidData()
        {
            var mainMenu = new MainMenuPageObject(_webDriver);
            mainMenu
                .Registration()
                .RegistrationValidData();
           var actual = _webDriver.FindElement(_afterSuccessfullRegister).Text;

            Assert.AreEqual(_expectedRegistrationResult, actual, "Registration wasn't completed");

        }

        [Test]
        public void TryToRegisterWhenEmailExists()
        {
            var mainMenu = new MainMenuPageObject(_webDriver);
            mainMenu
                .Registration()
                .RegistrationValidData();
          
           var actualResult = _webDriver.FindElement(_UnsuccessfullRegistrationEmailAlreadyRegistred).Text;
             Thread.Sleep(3000);
            Assert.AreEqual(_expectedAfterUnsuccessfullRegisterWhenEmailAlreadyRegistred, actualResult,"Error! This Email was already registred, but registration completed.");

        }

        [Test]
        public void AuthorizationUsingValidData()
        {
            var mainMenu = new MainMenuPageObject(_webDriver);
            mainMenu
                .Authorization()
                .AuthorizationUsingValidData();
            var actual2 = _webDriver.FindElement(_afterSuccessfullLogin).Text;
            Thread.Sleep(2000);
            Assert.AreEqual(_expectedLogin, actual2, "Login or password is wrong.");

        }

        [Test]
        public void AddItemToShoppingCart()
        {   
            var mainMenu = new MainMenuPageObject(_webDriver);
            mainMenu.OpenItemPage();
            mainMenu.AddToCartFromItemPage();
        }

        [Test]
        public void Task3AddToCompareList()
        {
            var mainMenu = new LeftSidebarMenuPageObject(_webDriver);
            mainMenu.OpenComputersMenu();
            mainMenu.OpenPageOfDesktops();
            var other = new CatalogOfProductsPageObject(_webDriver);
            other.SortDesktopsByNameZtoA()
                .SelectFirstComputer();
            var addCompareList = new ItemPagePageObject(_webDriver);
            addCompareList.AddToCompareList();
            WaitUntil.WaitElement(_webDriver, _actualPriceInCompareList);
            var actualResultCompareListPrise = _webDriver.FindElement(_actualPriceInCompareList).Text;
            Assert.AreEqual(_expectedPriceInCompareList, actualResultCompareListPrise, "Price is not correct");
        }

        [Test]
        public void ContactUsFormPageTests()
        {
            var mainMenu = new MainMenuPageObject(_webDriver);
            mainMenu.OpenContactUsForm();
            var other = new ContactUsFormPagePageObject(_webDriver);
            other.EnterDataToNameAndEmaiFields()
                .EnterRandomMessage()
                .SendMessageInContactUsForm();
            var actualResultSendMessage = _webDriver.FindElement(_actualResultAfterSendingMessage).Text;
            WaitUntil.WaitElement(_webDriver, _actualResultAfterSendingMessage);
            Assert.AreEqual(_expectedResultAfterSendingMessage, actualResultSendMessage, "Error! Message didn't send");
        }

        [Test]
        public void Task5Tests()
        {
            //var authorize = new AuthorizationFormPageObject(_webDriver);
            //authorize.AuthorizationUsingValidData();
            var cart = new ShoppingCartPageObject(_webDriver);
            var other = new LeftSidebarMenuPageObject(_webDriver);
            var mainMenu = new MainMenuPageObject(_webDriver);
            mainMenu.OpenGiftCardCategoryPage();
            var catalogMenu = new CatalogOfProductsPageObject(_webDriver);
            catalogMenu.Select100DollarsGiftCard();
            var itemMenu = new ItemPagePageObject(_webDriver);
            itemMenu.EnterDataForGiftCard();
            mainMenu.OpenBooksCategoryPage();
            catalogMenu.SelectAnyBook();
            itemMenu.AddToCartChosenBook();
            other.OpenComputersMenu()
                .OpenPageOfNotebooks();
            catalogMenu.SelectNotebook();
            itemMenu.AddToCartChosenNotebook();
            other.OpenPageOfJawerly();
            catalogMenu.SelectJawerly();
            itemMenu.AddToCartChosenJawerly();
            mainMenu.OpenShoppingCartPage();
            cart.SelectCountryAndAgreeButton();
            var authorize = new AuthorizationFormPageObject(_webDriver);
            authorize.AuthorizationUsingValidData();
            mainMenu.OpenShoppingCartPage();
            cart.SelectCountryAndAgreeButton()
                .EndingOfCheckout();
            WaitUntil.WaitElement(_webDriver, _actualResultOfCheckout);
            var actualCheckout = _webDriver.FindElement(_actualResultOfCheckout).Text;
            Assert.AreEqual(_expectedResultAfterCheckout, actualCheckout, "Error! Order can not create!");
        }

        [Test]
        public void Task6Tests()
        {
            // ������� "������� �����" ��� ������� � ������� (Delete the bank card information added in past cases.) -  ���. ��� ������� ��������� �� ������������ � ������ �����, ��� ������ �� ������� ������, �� �����������.
            // �� ������ ������ � ������ Mastercard ������� ���������� "4149", ���� ������ �� �������, ������� ������ ����. ����� �������� � ���.
        }

        [Test]
        public void FacebookButtonTask7Tests()
        {
            string actualFacebook = "https://www.facebook.com/nopCommerce";
            var footer = new FooterMenuPageObject(_webDriver);
            footer.OpenFacebookPage();
            _webDriver.SwitchTo().Window(_webDriver.WindowHandles.Last());
            Assert.AreEqual(actualFacebook.ToLower(), _webDriver.Url.ToLower());
        }

        [Test]
        public void TwitterButtonTask7Tests()
        {
            string actualTwitter = "https://twitter.com/nopCommerce";
            var footer = new FooterMenuPageObject(_webDriver);
            footer.OpenTwitterPage();
            _webDriver.SwitchTo().Window(_webDriver.WindowHandles.Last());
            Assert.AreEqual(actualTwitter.ToLower(), _webDriver.Url.ToLower());
        }

        [Test]
        public void YoutubeButtonTask7Tests()
        {
            string actualYoutube = "https://www.youtube.com/user/nopCommerce";
            var footer = new FooterMenuPageObject(_webDriver);
            footer.OpenYoutubePage();
            _webDriver.SwitchTo().Window(_webDriver.WindowHandles.Last());
            Assert.AreEqual(actualYoutube.ToLower(), _webDriver.Url.ToLower());
        }

        [Test]
        public void GooglePlusButtonTask7Tests()
        {
            string actualGooglePlus = "https://plus.google.com/+nopcommerce";
            var footer = new FooterMenuPageObject(_webDriver);
            footer.OpenGooglePlusPage();
            _webDriver.SwitchTo().Window(_webDriver.WindowHandles.Last());
            Assert.AreEqual(actualGooglePlus.ToLower(), _webDriver.Url.ToLower());
        }

        [Test]
        public void RssButtonTask7Tests()
        {
            string actualRss = "http://demowebshop.tricentis.com/news/rss/1";
            var footer = new FooterMenuPageObject(_webDriver);
            footer.OpenRssPage();
            _webDriver.SwitchTo().Window(_webDriver.WindowHandles.Last());
            Assert.AreEqual(actualRss.ToLower(), _webDriver.Url.ToLower());
        }
    }
}