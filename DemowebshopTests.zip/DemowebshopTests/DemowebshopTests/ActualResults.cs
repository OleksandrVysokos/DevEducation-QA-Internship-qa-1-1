﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;

namespace DemowebshopTests
{

    class ActualResults
    {
        private IWebDriver _webdriver;
        private readonly By _afterSuccessfullRegister = By.XPath("//div[@class='result']");
        private readonly By _UnsuccessfullRegistrationEmailAlreadyRegistred = By.XPath("//div[@class='validation-summary-errors']");
        private readonly By _afterSuccessfullLogin = By.XPath("//a[@class='account']");
        private readonly By _actualPriceInCompareList = By.XPath("//tr[@class='product-price']");
        private readonly By _actualResultAfterSendingMessage = By.XPath("//div[@class='result']");
        private readonly By _actualResultOfCheckout = By.XPath("//div[@class='title']");
    }
}
