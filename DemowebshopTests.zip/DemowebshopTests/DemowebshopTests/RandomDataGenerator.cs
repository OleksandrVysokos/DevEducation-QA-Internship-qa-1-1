﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemowebshopTests
{
    class RandomDataGenerator
    {
        public static string GenerateRandomString(int size, bool lowerCase = true)
        {
            StringBuilder stringBuilder = new StringBuilder();
            Random random = new Random();
            char x;
             for(int i = 0; i < size; i++)
             {
                x = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                stringBuilder.Append(x);
             }
            if (lowerCase)
                return stringBuilder.ToString().ToLower();
            return stringBuilder.ToString();
            

           
        }
    }
}
